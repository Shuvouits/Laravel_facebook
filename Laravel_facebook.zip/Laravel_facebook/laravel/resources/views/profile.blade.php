<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
	<link rel="shortcut icon" type="image/png" href="{{asset('icon/icon.jpg')}}">
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="{{asset('style.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('style1.css')}}">
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-4">
				<br>
				<div class="jumbotron">
					
						 <a href="" style="text-decoration:none">
						 	<?php
					         	$session_email = session()->get('email');
					         	$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	$run_data = DB::select($get_data);

					         	$data = $run_data;
					         	
					         	foreach ($data as $item) {
					         		$image = $item->image;



					         		
					         		echo "
					         		   <img src='images/$image' style='width: 100px;height: 100px;border-radius: 100%;border:2px solid gray'>

					         		";					         		
					         	}
					         	?>

					         	


					        
					         <span style="font-weight: bold">
					         	<?php

					         	$session_email = session()->get('email');
					         	$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	$run_data = DB::select($get_data);

					         	$data = $run_data;
					         	
					         	foreach ($data as $item) {
					         		$f_name = $item->f_name;
					         		$l_name = $item->l_name;
					         		$id = $item->id;
					         		echo "<span>$f_name</span><span style='margin-left:5px'>$l_name</span>";
					         		
					         	}
					         	?>
					         
					         </span>
				        </a>
				        <br>
				        <br>
				        <br>
				    <div class="col-md-12">
						<a href="#" data-toggle="modal" data-target="#change_profile">
							<i class="fa fa-camera" style="font-size: 25px;">
								<span style="font-size: 19px; margin-left:30px;font-weight: bold">Change profile</span>
							</i>
						</a>
					</div>

					<br>
				    <br>
				    <br>

				    <div class="col-md-12">
						<a href="#" data-toggle="modal" data-target="#add_picture">
							<i class="fa fa-picture-o" style="font-size: 25px;">
								<span style="font-size: 19px; margin-left:30px;font-weight: bold">Add picture</span>
							</i>
						</a>
					</div>

					<br>
				    <br>
				    <br>

					
					<div class="col-md-12">
						<a href="#" data-toggle="modal" data-target="#add_information">
							<i class="fa fa-plus" style="font-size: 25px;">
								<span style="font-size: 19px; margin-left:30px;font-weight: bold">Add information</span>
							</i>
						</a>
					</div>
					<br>
				    <br>
				    <br>
					<div class="col-md-12">
						<a href="#" data-toggle="modal" data-target="#add_friend">
							<i class="fa fa-users" style="font-size: 25px;">
								<span style="font-size: 19px; margin-left:30px;font-weight: bold">Add Friend</span>
							</i>
						</a>
					</div>
					<br>
				    <br>
				    <br>
					<div class="col-md-12">
						<a href="#" data-toggle="modal" data-target="#about_profile">
							<i class="fa fa-user-circle-o" style="font-size: 25px;">
								<span style="font-size: 19px; margin-left:30px;font-weight: bold">About profile </span>
							</i>
						</a>
					</div>
					<br>
				    <br>
				    <br>
					<div class="col-md-12">
						<a href="#" data-toggle="modal" data-target="#friend_list">
							<i class="fa fa-list" style="font-size: 25px;">
								<span style="font-size: 19px; margin-left:30px;font-weight: bold">Friend list </span>
							</i>
						</a>
					</div>
					<br>
				    <br>
				    <br>
					<div class="col-md-12">
						<a href="#" data-toggle="modal" data-target="#entertainment">
							<i class="fa fa-play" style="font-size: 25px;">
								<span style="font-size: 19px; margin-left:30px;font-weight: bold">Entertainment </span>
							</i>
						</a>
					</div>
			    </div>
			</div>
			<br>


			<div class="col-md-6 jumbotron">
				<div class="col-md-12" style="margin-bottom: 40px">
					<ul style="text-decoration: none">
                         
                         <li>
                         	<a  href="#" style="text-decoration: none"; data-toggle="modal" data-target="#message">
                         		Message
                         	</a>
                         </li>
                         <li>
                         	<a href="#" style="text-decoration: none"; data-toggle="modal" data-target="#nav-post">Post</a>
                         </li>

                         <li>
                         	<a href="#" style="text-decoration: none;" data-toggle="modal" data-target="#album"> Album</a>
                         </li>
                    </ul>
				</div>

				

				<div class="col-md-3">

					<?php

					         	$session_email = session()->get('email');
					         	$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	$run_data = DB::select($get_data);

					         	$data = $run_data;
					         	
					         	foreach ($data as $item) {
					         		$image = $item->image;



					         		
					         		echo "

					         		<img src='images/$image' style='width: 50px;height: 50px;border-radius: 100%;border:2px solid gray'>
					         		  
					         		";					         		
					         	}
					 ?>


				</div>
				<div class="col-md-9">
					<form  action="" data-toggle="modal" data-target="#post">
				 	     {{@csrf_field()}}
				 	     <div class="form-group input-group-lg">
				 		     <input type="text" name="" class="form-control" placeholder="create your post">
				 		
				 	     </div>
				 	
				    </form>
				</div>

			</div>


			<div class="col-md-2">
				<div class="row">
					<div class="col-md-12">
						<div class="jumbotron">
							<?php

							    $session_email = session()->get('email');
					         	$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	$run_data = DB::select($get_data);

					         	$data = $run_data;
					         	foreach($data as $item)
					         	{
					         		$session_id = $item->id;
					         		echo "

					         		<a href='logout/$session_id' class='btn btn-primary'>log out</a>

					         		";
					         	}

							?>
					         
				        </div>
					</div>

					<!-----show Friends--->

					<div class="col-md-12">
						<h4 class="text-center">Friends</h4>
						<div class="" style="background-color:#DBDCDD; height: 350px;">

							<!-----Active online--->
							
								<?php

								$session_email = session()->get('email');
					         	$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	$run_data = DB::select($get_data);

					         	$data = $run_data;
					         	foreach($data as $item)
					         	{
					         		$session_id = $item->id;

					         		$get_user_data = "SELECT * FROM users WHERE id !=$session_id AND status='online' ORDER BY f_name ASC";
					         		$run_user_data = DB::select($get_user_data);
					         		$data_user = $run_user_data;

					         		foreach($data_user as $item_user)
					         		{
					         			$f_name = $item_user->f_name;
					         			$l_name = $item_user->l_name;
					         			$user_image = $item_user->image;
					         			$user_id = $item_user->id;

					         			$get_friends_data = "SELECT * FROM friends WHERE user_id = $session_id AND friend_id =$user_id ";
					         			$run_friends_data = DB::select($get_friends_data);
					         			$data_friends = $run_friends_data;

					         			foreach($data_friends as $item_friends)
					         			{
					         				echo "
					         			     <a href='#' style='text-decoration:none' data-toggle='modal' data-target='#$user_id'>
					         			     <br>

							                     <span style='margin-left: 10px; color:green'>
								                     <i class='fa fa-circle' aria-hidden='true'></i>
							                     </span>
							                     <img src='images/$user_image' style='width:50px; height: 50px; border-radius:100%'>
							                     <span style='margin-left: 10px; font-weight: bold; color:green'>$f_name $l_name</span>
					         			     </a>
					         			     <br>


					         			 ";

					         			}

					         			
					         		}

					         	}

								?>
								
						    
						    <br>

						    <!----Active offline--->

						    <?php

								$session_email = session()->get('email');
					         	$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	$run_data = DB::select($get_data);

					         	$data = $run_data;
					         	foreach($data as $item)
					         	{
					         		$session_id = $item->id;

					         		$get_user_data = "SELECT * FROM users WHERE id !=$session_id AND status='offline' ORDER BY f_name ASC";
					         		$run_user_data = DB::select($get_user_data);
					         		$data_user = $run_user_data;

					         		foreach($data_user as $item_user)
					         		{
					         			$f_name = $item_user->f_name;
					         			$l_name = $item_user->l_name;
					         			$user_image = $item_user->image;
					         			$user_id = $item_user->id;

					         			$get_friends_data = "SELECT * FROM friends WHERE user_id = $session_id AND friend_id =$user_id ";
					         			$run_friends_data = DB::select($get_friends_data);
					         			$data_friends = $run_friends_data;

					         			foreach($data_friends as $item_friends)
					         			{
					         				echo "
					         			     <a href='#' style='text-decoration:none' data-toggle='modal' data-target='#$user_id'>
					         			     <br>

							                     <span style='margin-left: 10px; color:black'>
								                     <i class='fa fa-circle' aria-hidden='true'></i>
							                     </span>
							                     <img src='images/$user_image' style='width:50px; height: 50px; border-radius:100%'>
							                     <span style='margin-left: 10px; font-weight: bold; color:black'>$f_name $l_name</span>
					         			     </a>
					         			     <br>


					         			";

					         			}


					         		}

					         	}

						     ?>

						   
						</div>
						
					</div>
				</div>



				<!-- nav-post modal -->
                <div id="nav-post" class="modal fade" role="dialog">
                     <div class="modal-dialog">

                            <!-- Modal content-->
                         <div class="modal-content">
                             <div class="modal-header">
                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                                     <h4 class="modal-title text-center">All user post</h4>
                                      <br>
                                      <br>
                                      <?php                   

                                             $session_email = session()->get('email');
					         	             $get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	             $run_data = DB::select($get_data);

					         	             $data = $run_data;
					         	
					         	             foreach ($data as $item)
					         	             {
					         		             
					         		             
					         		             $session_id = $item->id;
					         		             //$image = $item->image;

					         		             $get_post = "SELECT * FROM post ORDER BY id DESC";
                                                 $run_post = DB::select($get_post);
                                                 $data_post = $run_post;

                                                 foreach($data_post as $item_post)
                                                 {
                                                 	 $id = $item_post->id;
                                     	             $user_id = $item_post->user_id;
                                     	             $post_image = $item_post->image;
                                     	             $time = $item_post->time;
                                     	             $date = $item_post->date;
                                     	             $text = $item_post->text;
                                     	             $user_image = $item_post->user_image;
                                     	             $f_name = $item_post->f_name;
                                     	             $l_name = $item_post->l_name;

                                     	             if($user_id == $session_id)
                                     	             {
                                     		             echo "
                                	                         <div class='row'>
		 	                                                     <div class='col-md-6' style='margin-bottom: 30px'>
		 		                                                     <img src='images/$user_image' style='width:50px;height:50px;'>
		 	                                                         <span style='font-weight: bold'>
		 	                                                             $f_name $l_name
		 	                                                             
		 	                                                         </span>
		 	                                                    </div>
		 	                                                     <div class='col-md-6' style='margin-top: 15px'>
		 		                                                     <p>Time($time) Date:$date</p>

		 	                                                     </div>
		 	                                                     <br>
		 	                                                     <div class='col-md-8 col-md-offset-2' style='margin-bottom: 30px;'>
		 	                                                     ";
		 	                                                     if($post_image != '')
		 	                                                     {
		 	                                                     	echo "
		 		                                                      <img src='images/$post_image' style='width:300px;height: 300px'>
		 		                                                     ";
		 	                                                     }
		 		                                                 echo "
		 	                                                     </div>
		 	
		 	                                                     <div class='col-md-12'>
		 		                                                     <p class='text-center'>
		 		                                                         $text 
		 		                                                          <a href='delete-post/$id' class='btn btn-danger' style='margin-left: 10px;'> Delete
		 		                                                          </a>
		 		                                                          <a href='#' class='btn btn-info' style='margin-left:10px' data-toggle='modal' data-target='#$id'>Edit
		 	                                                             </a>
		 	                                                        </p>

		 	                                                    </div>
		 	
		                                                    </div>

		                                    
		                                                ";

                                     	             }else{
                                     	             	echo "

                                     	             	<div class='row'>
		 	                                                     <div class='col-md-6' style='margin-bottom: 30px'>
		 		                                                     <img src='images/$user_image' style='width:50px;height:50px;'>
		 	                                                         <span style='font-weight: bold'>
		 	                                                             $f_name $l_name
		 	                                                         </span>
		 	                                                    </div>
		 	                                                     <div class='col-md-6' style='margin-top: 15px'>
		 		                                                     <p>Time($time) Date:$date</p>
		 	                                                     </div>
		 	                                                     <br>
		 	                                                     <div class='col-md-8 col-md-offset-2' style='margin-bottom: 30px;'>
		 	                                                     ";

		 	                                                     if($post_image != '')
		 	                                                     {
		 	                                                     	echo "
		 		                                                      <img src='images/$post_image' style='width:300px;height: 300px'>
		 		                                                     ";
		 	                                                     }
		 		                                                      
		 		                                                 echo "
		 	                                                     </div>
		 	
		 	                                                     <div class='col-md-12'>
		 		                                                     <p class='text-center'>
		 		                                                          $text 
		 		                                                          
		 	                                                        </p>

		 	                                                    </div>
		 	
		                                                    </div>


                                     	             	";
                                     	             }
                                	
                                                 }

                                             }
					         	
		                              ?>
		 
      
                                 <div class="modal-footer">
                                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                            </div>

                        </div>

                    </div>
				
			    </div>

			    <!---Edit post modal--->
			    <?php

			        $session_email = session()->get('email');
					$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					$run_data = DB::select($get_data);

					$data = $run_data;
					foreach($data as $item)
					{
						$session_id= $item->id;

						$get_post_data = "SELECT * FROM post WHERE user_id = $session_id";
						$run_post_data = DB::select($get_post_data);
						$data_post = $run_post_data;

						foreach($data_post as $item_post)
						{
							$post_id = $item_post->id;
							$text = $item_post->text;
							$post_image = $item_post->image;

							echo "

							
                            <div id='$post_id' class='modal fade' role='dialog'>
                                 <div class='modal-dialog'>

    
                                     <div class='modal-content'>
                                         <div class='modal-header'>
                                             <button type='button' class='close' data-dismiss='modal'>&times;
                                             </button>
                                             <h4 class='modal-title'>Modal Header</h4>
                                             <br>
                                             <br>
                                             <form action='edit-post' method='post' enctype='multipart/form-data'>
                                             ";

                                                 echo csrf_field();

                                             echo "
                                                  <div class='form-group'>
                                                     <textarea class='form-control' rows='5' id='comment' name='text'>$text
                                                     </textarea>
                                                  </div>
                                             ";
                                                  if($post_image)
                                                  {
                                                  	echo "

                                                  	<div class='form-group'>
                                                      <input type='file' name='image' class='form-control'>
                                                      <img src='images/$post_image' style='width:50px; height:50px'>
                                                      <input type='hidden' name='check' value='check'>
                                                      

                                                    </div>


                                                  	";
                                                  }
                                                  
                                             echo "
                                                  <input type='hidden' name ='post_id' value='$post_id'>
                                                  <input type= 'submit' class='btn btn-primary' value='Update'>
                                             </form>
                                         </div>
      
                                             <div class='modal-footer'>
                                                 <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
                                             </div>
                                    </div>

                                 </div>
                             </div>

							";
						}
					}

			    ?>


			       



			         <!-- Message Online Modal -->
			        <?php

			                    $session_email = session()->get('email');
					         	$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	$run_data = DB::select($get_data);
					         	$data = $run_data;

					         	foreach($data as $item)
					         	{
					         		$session_id = $item->id;
					         		$session_f_name = $item->f_name;
					         		$session_l_name = $item->l_name;

					         		$user_data = "SELECT * FROM users WHERE id!=$session_id AND status='online' ORDER BY f_name DESC ";
					         		$run_user_data = DB::select($user_data);
					         		$data_user = $run_user_data;

					         		foreach($data_user as $item_user)
					         		{
					         			 $user_id = $item_user->id;
					         			 $user_image = $item_user->image;
					         			 $f_name = $item_user->f_name;
					         			 $l_name = $item_user->l_name;
					         			
					         			echo "

					         			 <div id='$user_id' class='modal fade' role='dialog'>
                                             <div class='modal-dialog'>

                                                  <!-- Modal content-->
                                                 <div class='modal-content'>
                                                         <div class='modal-header'>
                                                             <button type='button' class='close' data-dismiss='modal'>&times;</button>
                                                             <h4 class='modal-title'>Send message</h4>
                                                             <br>
                                                             <form action='message-online' method='post'>
                                         ";
                                                              echo csrf_field();

                                         echo "
                                                                 <div class='form-group'>
                                                                     <img src='images/$user_image' style='width:50px; height:50px'>
                                                                         <span style='font-weight:bold'>$f_name $l_name</span>
                                                                     <br>
                                                                     <br>
                                                                     <textarea class='form-control' rows='5' id='comment' name='text' required>
                                                                     </textarea>
                                                                 </div>
                                                                 <input type='hidden' value='$user_id' name='receiver'>
                                                                 <input type='hidden' name='sender' value='$session_id'>
                                                                 <input type='hidden' value='$session_f_name' name='f_name'>
                                                                 <input type='hidden' value='$session_l_name' name='l_name'>
                                                                 <input type='submit' name='submit' value='Send message' class='btn btn-primary'>
                                                             </form>
                                                         </div>
                                                         
                                                         <div class='modal-footer'>
                                                             <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
                                                         </div>
                                                 </div>

                                             </div>
                                         </div>


					         			 ";
					         		}
					         	}

			        ?>


			         <!-- Message Offline Modal -->
			        <?php

			                    $session_email = session()->get('email');
					         	$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	$run_data = DB::select($get_data);
					         	$data = $run_data;

					         	foreach($data as $item)
					         	{
					         		$session_id = $item->id;
					         		$session_f_name = $item->f_name;
					         		$session_l_name = $item->l_name;
					         		

					         		$user_data = "SELECT * FROM users WHERE id!=$session_id AND status='offline' ORDER BY f_name DESC ";
					         		$run_user_data = DB::select($user_data);
					         		$data_user = $run_user_data;

					         		foreach($data_user as $item_user)
					         		{
					         			 $user_id = $item_user->id;
					         			 $user_image = $item_user->image;
					         			 $f_name = $item_user->f_name;
					         			 $l_name = $item_user->l_name;
					         			 echo "

					         			 <div id='$user_id' class='modal fade' role='dialog'>
                                             <div class='modal-dialog'>

                                                  <!-- Modal content-->
                                                 <div class='modal-content'>
                                                         <div class='modal-header'>
                                                             <button type='button' class='close' data-dismiss='modal'>&times;</button>
                                                             <h4 class='modal-title'>Send message</h4>
                                                             <br>
                                                             <form action='message-offline' method='post'>
                                         ";
                                                              echo csrf_field();

                                         echo "
                                                                 <div class='form-group'>
                                                                     <img src='images/$user_image' style='width:50px; height:50px'>
                                                                         <span style='font-weight:bold'>$f_name $l_name</span>
                                                                     <br>
                                                                     <br>
                                                                     <textarea class='form-control' rows='5' id='comment' name='text' required>
                                                                     </textarea>
                                                                 </div>
                                                                 <input type='hidden' value='$user_id' name='receiver'>
                                                                 <input type='hidden' name='sender' value='$session_id'>
                                                                 <input type='hidden' value='$session_f_name' name='f_name'>
                                                                 <input type='hidden' value='$session_l_name' name='l_name'>

                                                                 <input type='submit' name='submit' value='Send message' class='btn btn-primary'>
                                                             </form>
                                                         </div>
                                                         
                                                         <div class='modal-footer'>
                                                             <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
                                                         </div>
                                                 </div>

                                             </div>
                                         </div>


					         			 ";
					         		}
					         	}

			        ?>


			        <!-- Nav show message Modal -->
                    <div id="message" class="modal fade" role="dialog">
                         <div class="modal-dialog">

                             <!-- Modal content-->
                            <div class="modal-content">
                                 <div class="modal-header">
                                     <button type="button" class="close" data-dismiss="modal">&times;</button>
                                     <h4 class="modal-title text-center">Message</h4>

                                     <?php
                                         $session_email = session()->get('email');
					         	         $get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	         $run_data = DB::select($get_data);

					         	         $data = $run_data;
					         	         foreach($data as $item)
					         	         {
					         	         	$session_id = $item->id;

					         	         	$get_message_data = "SELECT * FROM message WHERE receiver_id = $session_id";
					         	         	$run_message_data = DB::select($get_message_data);

					         	         	$data_message  =$run_message_data;
					         	         	foreach($data_message as $item_message)
					         	         	{
					         	         		$text = $item_message->text;
					         	         		$sender_image = $item_message->sender_image;
					         	         		$sender_f_name = $item_message->s_f_name;
					         	         		$sender_l_name = $item_message->s_l_name;
					         	         		$id = $item_message->id;

					         	         		echo "

					         	         		<div class='col-md-12' style='margin-bottom:20px;'>

					         	         		 <img src='images/$sender_image' style='width:50px; height: 50px; margin-bottom: 10px'> 
                                                 <span style='font-weight: bold;margin-left:10px'>$sender_f_name $sender_l_name</span>
                                     
                                                 <p style='font-weight: bold; color:blue;'>$text</p>
                                     
                                                 <a href='delete-message/$id' class='btn btn-danger'>Delete</a>
                                                  

                                                  </div>


					         	         		";
					         	         	}
					         	         }


                                     ?>
                                     
                                 </div>
                                 
                                 <div class="modal-footer">
                                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                 </div>
                             </div>

                          </div>
                    </div>


			        
			</div>
			
		  

	





<!-- change profile modal -->
<div id="change_profile" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text-center">Change profile</h4>
        <br>
        <br>
        <form method="post" action="change-profile" enctype="multipart/form-data">
        	{{@csrf_field()}}
        	<div class="form-group">
        		<input type="file" name="image" class="form-control" required>
        	</div>
        	<?php

					         	$session_email = session()->get('email');
					         	$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	$run_data = DB::select($get_data);

					         	$data = $run_data;
					         	
					         	foreach ($data as $item) {
					         		
					         		$id = $item->id;
					         		echo "
					         		<input type='hidden' name='id' value='$id'>

					         		";
					         	}
		    ?>
        	
        	<input type="submit" name="submit" value="submit" class="btn btn-primary">
        	
        </form>
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>



<!-- add picture modal -->
<div id="add_picture" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Upload your photo</h4>
        <br>
        <br>
        <form method="post" action="add-picture" enctype="multipart/form-data">
        	{{@csrf_field()}}
        	<div class="form-group">
        		<input type="file" name="image" class="form-control" required>
        		<br>
        		<?php

					         	$session_email = session()->get('email');
					         	$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	$run_data = DB::select($get_data);

					         	$data = $run_data;
					         	
					         	foreach ($data as $item) {
					         		$session_id = $item->id;



					         		
					         		echo "

					         		<input type='hidden' value='$session_id' name='user_id'>
					         		  
					         		";					         		
					         	}
				?>

			    <div class="form-group">
                     <label for="comment">Comment about picture:</label>
                     <textarea class="form-control" rows="5" id="comment" name='comment' required></textarea>
                </div>

        		<input type="submit" name="submit" value="Submit" class="btn btn-primary">

        	</div>
        	
        </form>
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- add information modal -->
<div id="add_information" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text-center">Add information</h4>
        <br>
        <form  method="post" action="add-information">
        	{{@csrf_field()}}
        	<div class="form-group">
        		<input type="text" name="university" class="form-control" placeholder="Add your University" required>
        	</div>
        	<div class="form-group">
        		<input type="text" name="address" class="form-control" placeholder="Add your Address" required>
        	</div>
        	<div class="form-group">
        		<input type="text" name="country" class="form-control" placeholder="Add your Country" required>
        	</div>
        	<div class="form-group">
        		<input type="text" name="city" class="form-control" placeholder="Add your City" required>
        	</div>
        	<div class="form-group">
        		<input type="text" name="phone" class="form-control" placeholder="Add your phone number" required>
        	</div>
        	<?php

					         	$session_email = session()->get('email');
					         	$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	$run_data = DB::select($get_data);

					         	$data = $run_data;
					         	
					         	foreach ($data as $item) {
					         		
					         		$id = $item->id;
					         		echo "
					         		<input type='hidden' name='id' value='$id'>

					         		";
					         	}
		    ?>

        	<input type="submit" name="submit" class="btn btn-primary" value="submit" required>
        	
        </form>
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
        	
    </div>

  </div>
</div>

<!-- add friend Modal -->
<div id="add_friend" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text-center">Add friend</h4>
        <br>
        <br>
        
        	<?php

					         	
					         	

                                    $session_email = session()->get('email');
					         		$get_id ="SELECT * FROM users WHERE email = '$session_email' ";
					         		$run_data = DB::select($get_id);

					         		$data_id = $run_data;

					         		foreach ($data_id as $item_id)
					         		 {
					         		 	$session_id = $item_id->id;
					         		 	
					         		 	$get_data = "SELECT * FROM users WHERE id !=$session_id ";
					         		 	$run_data = DB::select($get_data);
					         		 	$data = $run_data;

					         		 	foreach ($data as $item)
					         		 	 {
					         		 		$id = $item->id;
					         		 		$first_name = $item->f_name;
					         		 		$last_name = $item->l_name;
					         		 		$image = $item->image;

					         		 		$check_friend = "SELECT * FROM friends WHERE user_id = $session_id AND friend_id = $id ";
					         		 		$run_check_data = DB::select($check_friend);
					         		 		$count = count($run_check_data);

					         		 		if($count==0)
					         		 		{
					         		 			echo "

					         		 			<div class='col-md-12' style='margin-bottom:30px;'>
					         		                <input type='hidden' name='friend_id' value='$id'>
					         		                <input type='hidden' name='user_id' value='$session_id'>
					         		                <img src='images/$image' style='width: 100px; height: 100px'>
					         		                <span>$first_name</span>
					         		                <span style='margin-left:5px'>$last_name</span>
        	                                        <a href='add-friend/$id'  class='btn btn-primary' style='margin-left:10px'>Add friend
        	                                        </a>
        	                                    </div>

					         		 			";

					         		 		}

					         		 		$data_check = $run_check_data;



					         		 		//$count = count($run_check_data);
					         		 		foreach($data_check as $item_check)
					         		 		{
					         		 			echo "

					         		 			<div class='col-md-12' style='margin-bottom:30px;'>
					         		                <input type='hidden' name='friend_id' value='$id'>
					         		                <input type='hidden' name='user_id' value='$session_id'>
					         		                <img src='images/$image' style='width: 100px; height: 100px'>
					         		                <span>$first_name</span>
					         		                <span style='margin-left:5px'>$last_name</span>
        	                                        <a href='#'  class='btn btn-default' style='margin-left:10px'>Friend
        	                                        </a>
        	                                    </div>

					         		 			";
					         		 			
					         		 		}

					         		 		
					         		     }
					         		 	
					         		 } 
					         		
					         		
					         		

					         	
		    ?>
        	
        	
        
        
        
      </div>
     
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- about profile Modal -->
<div id="about_profile" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text-center">Profile details</h4>
        
        <br>
        <div class="card">
        	<?php

        	$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
        	$run_data = DB::select($get_data);

        	$data = $run_data;
        	foreach ($data as $item) 
        	{
        		$f_name = $item->f_name;
        		$l_name = $item->l_name;
        		$image = $item->image;
        		$day = $item->day;
        		$month = $item->month;
        		$year = $item->year;
        		$gender = $item->gender;
        		$university = $item->university;
        		$address = $item->address;
        		$city = $item->city;
        		$phone = $item->phone;
        		$country = $item->country;

        		echo "
        		   <img src='images/$image' alt='John' style='width:300px;height: 300px'>
        		   <h1>$f_name <span style='margin-left:5px'>$l_name</span></h1>
        		   <p class='title'>$university</p>
        		   <p style='font-weight:bold'>Gender: $gender</p>
        		   <p style='font-weight:bold'>Date of Birth: $day-$month-$year</p>
        		   <p style='font-weight:bold'>Address: $address</p>
        		   <p style='font-weight:bold'>City: $city</p>
        		   <p style='font-weight:bold'>Phone: $phone</p>
        		   <p style='font-weight:bold'>Country: $country</p>
        		   <br>
        		   


        		";
        	}

        	?>

        </div>
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- Friend list Modal -->
<div id="friend_list" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text-center">Your friend list</h4>
        <?php
        $session_email = session()->get('email');
        $get_data = "SELECT * FROM users WHERE email = '$session_email' ";
        $run_data = DB::select($get_data);
        $data = $run_data;

        foreach($data as $item)
        {
        	$session_id = $item->id;

        	$get_friend_data = "SELECT * FROM friends WHERE user_id = $session_id ";
        	$run_friend_data = DB::select($get_friend_data);
        	$friend_check = $run_friend_data;

        	foreach($friend_check as $item_check)
        	{
        		$friend_id = $item_check->friend_id;
        		
        		$get_user_data = "SELECT * FROM users WHERE id =$friend_id ";
        		$run_user_data = DB::select($get_user_data);
        		
        		$data_user = $run_user_data;

        		foreach($data_user as $item_user)
        		{
        			$f_name = $item_user->f_name;
        			$l_name = $item_user->l_name;
        			$image = $item_user->image;
        			$user_id = $item_user->id;
        			
        			echo "
                                                 
					         		 			
					         		            <div class='col-md-12' style='margin-bottom:30px;'>
					         		                <input type='hidden' name='friend_id' value='$id'>
					         		                <input type='hidden' name='user_id' value='$session_id'>
					         		                <img src='images/$image' style='width: 100px; height: 100px'>
					         		                <span>$f_name</span>
					         		                <span style='margin-left:5px'>$l_name</span>
        	                                        <a href='block-friend/$user_id'  class='btn btn-danger' style='margin-left:10px'> Block
        	                                        </a>
        	                                    </div>

			         ";
        		}
        	}
        }
        ?>
      </div>
     
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- post Modal -->
<div id="post" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text-center">Create your post</h4>
        <br>

        <form method="post" action="data-post" enctype="multipart/form-data">
        	{{@csrf_field()}}
        	<div class="form-group input-group-lg">
        		<input type="text" name="text" class="form-control" placeholder="Write something.." required>
        	</div>
        	<div class="form-group">
        		<input type="file" name="image" class="form-control">
        	</div>

        	<?php

					         	$session_email = session()->get('email');
					         	$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	$run_data = DB::select($get_data);

					         	$data = $run_data;
					         	
					         	foreach ($data as $item) {
					         		$session_id = $item->id;



					         		
					         		echo "
					         		   
                                       <input type='hidden' name='session_id' value='$session_id'>
					         		";					         		
					         	}
			 ?>

        	
        	<input type="submit" name="" class="btn btn-primary">
        	
        </form>
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
        	
    </div>

  </div>
</div>

<!-- Album Modal -->
<div id="album" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text-center">Your album</h4>
        <br>
        <br>
        <div class="row">

        	<?php

					         	$session_email = session()->get('email');
					         	$get_data = "SELECT * FROM users WHERE email = '$session_email' ";
					         	$run_data = DB::select($get_data);
					         	$data = $run_data;

					         	foreach($data as $item)
					         	{
					         		$session_id = $item->id;

					         		$get_post_data = "SELECT * FROM album WHERE user_id = $session_id ";
					         		$run_post_data = DB::select($get_post_data);
					         		$data_post = $run_post_data;

					         		foreach($data_post as $item_post)
					         		{
					         			$image = $item_post->image;
					         			$user_comment = $item_post->user_comment;
					         			echo "
					         			
					         			<div class='col-md-4'>
                                             <div class='thumbnail'>
                                                 <a href='images/$image'>
                                                 <img src='images/$image' alt='Lights' style='width:400px; height:200px'>
                                                 <div class='caption'>
                                                     <p>$user_comment</p>
                                                 </div>

                                                 </a>
                                            </div>
                                        </div>
                                        


					         			";
					         		}

					         	}
					         	
			?>
		</div>

           
        
     
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>









</body>
</html>