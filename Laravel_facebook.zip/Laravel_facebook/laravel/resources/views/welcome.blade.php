<!DOCTYPE html>
<html>
<head>
	<title>Facebook-log in or sign up</title>
	<link rel="shortcut icon" type="image/png" href="{{asset('icon/icon.jpg')}}">
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container-fluid">

		<div class="row" style="background-color: #0962DB  ">
			<div class="col-md-12">
				<div class="col-md-3">
					<a href="" style="text-decoration: none"><h3 style="color:white;font-weight: bold;">Facebook</h3></a>

				</div>

				<div class="col-md-9" style="margin-top:10px;">
					<form class="form-inline" action="login" method="post" style="margin-left: 250px">
						{{@csrf_field()}}
                         <div class="form-group">
                              <label for="email" style="color: white">Email address:</label>
                            <input type="email"  id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="pwd" style="color: white">Password:</label>
                            <input type="password"  id="pwd" name="password" required>
                        </div>
 
                       <button type="submit" class="" style="background-color:#154E9B; font-weight: bold; color:white;" name="login">Log In</button>

                       
                    </form>
                    <a href="#" style="color:white; margin-left:650px; text-decoration: none">Forgotten account?</a>
					
				</div>
			</div>
		</div>
		<div class="middle">
			<div class="row" style="background-color:#D9DBDD; height: 550px; ">
				<div class="col-md-5">
					<h2 style="font-weight: bold">Recent logins</h2>
					<p style="font-size: 20px">Click your picture or add an account.</p>
					<a href="#"><img src="{{asset('icon/jhon.jpg')}}" style="width:200px;height: 200px"></a>
				</div>
				<div class="col-md-4">

                    <p class="text-center">
					@if(Session::has('login_err'))
					     <span style="color:red">{{session('login_err')}}</span>
				    @endif
				    </p>
				    
				    

				    <h4 style="margin-left: 25px; color: green;">
				    	@if(Session::has('sign_up_success'))
					        {{session('sign_up_success')}}
				        @endif
				    
				    </h4>

					<h2 style="font-weight: bold; margin-left: 23px;">Create a new account</h2>
					<h4 style="margin-left:23px">It's quick and easy.</h4>
					<form method="post" action="signup">
						{{@csrf_field()}}
						<div class="row">
							<div class="col-md-12">

								<div class="form-group input-group-lg col-md-6">
							         <input type="text" name="f_name" class="form-control" placeholder="First name">

							         @error('f_name')
							         <span style="color:red">{{$message}}</span>
							         @enderror
						        </div>
						        <div class="form-group input-group-lg col-md-6">
							         <input type="text" name="l_name" class="form-control" placeholder="Last name">

							         @error('l_name')
							         <span style="color:red">{{$message}}</span>
							         @enderror
						        </div>
						        <div class="form-group input-group-lg col-md-12">
							         <input type="email" name="email" class="form-control" placeholder="Your Email">

							         @error('email')
							         <span style="color:red">{{$message}}</span>
							         @enderror

							         @if(Session::has('message'))
							         <span style="color:red">{{session('email')}}</span>
							         @endif
						        </div>
						         <div class="form-group input-group-lg col-md-12">
							         <input type="password" name="password" class="form-control" placeholder="Your new Password">

							         @error('password')
							         <span style="color:red">{{$message}}</span>
							         @enderror
						        </div>

                                <h4 style="margin-left:20px; font-weight: bold">Date Of Birth</h4>

                                    
						        <div class="form-group col-md-4">
						        	

						        	<label></label>
							         <select class="form-control" id="sel1" name="day">
							         	<?php
							         	$day = date("d");
							         	for($i=1;$i<32;$i++)
							         	{
							         		if($i==$day){
							         			echo "<option selected>$i</option>";
							         		}else{
                                              echo "<option>$i</option>";
							         		}
							         		
							         	}

							         	?>
                                         
                                    </select>
						        </div>
						        <div class="form-group col-md-4">
						        	<label></label>
							         <select class="form-control" id="sel1" name="month">
							         	<?php
							         	$m = date("m");
							         	$month = array('no one','January','February','March','April','May','June','July','August','September','October','November','December');

							         	for($i=1;$i<=12;$i++)
							         	{
							         		if($i==$m)
							         		{
							         			echo "<option selected>$month[$i]</option>";
							         		}else{
							         			echo "<option>$month[$i]</option>";

							         		}
                                           
							         	}

							         	?>
                                    </select>
						        </div>
						        <div class="form-group col-md-4">
						        	<label></label>
							         <select class="form-control" id="sel1" name="year">
							         	<?php
                                        $year = date("Y");
                                        echo $year;
							         	for($i=1980; $i<2021;$i++)
							         	{
							         		if($i==$year)
							         		{
							         			echo "<option selected>$i</option>";
							         		}else{
							         			echo "<option>$i</option>";
							         		}
							         		
							         	}

							         	?>
                                        
                                    </select>
                                    
						        </div>

						        <div class="col-md-12">
						        	 @if(Session::has('age'))
							             <span style="color:red">{{session('age')}}</span>
							         @endif
						        </div>

						       

						         
						        
						        <h4 style="margin-left:20px; font-weight: bold">Gender</h4>
						        <div class="col-md-12">
						        	 <input type="radio" id="male" name="gender" value="male"> <span style="font-size: 20px">Male</span>
						        	 <input type="radio" id="male" name="gender" value="male"> <span style="font-size: 20px">Female</span>
						        	 <input type="radio" id="male" name="gender" value="male"> <span style="font-size: 20px">Custom</span>

						        	 @error('gender')
							         <span style="color:red">{{$message}}</span>
							         @enderror
						        	
						        </div>
						        <br>
						        <br>
						        <div class="col-md-12">
						        	<input type="submit" name="signup" value="Sign Up" class="btn btn-success btn-lg">
						        </div>
						        
							</div>
							
						</div>
						
						

						
					</form>
				</div>
			</div>
		</div>
	</div>

</body>
</html>