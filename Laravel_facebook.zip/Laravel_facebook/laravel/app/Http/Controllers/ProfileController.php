<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;

class ProfileController extends Controller
{
    public function signup(Request $request){

        $request->validate([
            'f_name'=> 'required|min:3|max:20',
            'l_name'=> 'required|min:3|max:20',
            'email'=> 'required|email',
            'password'=>'required|min:5|max:20',
            'gender'=>'required'
        ]);
        $f_name = $request->input('f_name');
        $l_name = $request->input('l_name');
        $email = $request->input('email');
        $day = $request->input('day');
        $month = $request->input('month');
        $year = $request->input('year');
        $gender = $request->input('gender');
        $password = $request->input('password');

       

        $get_data = "SELECT * FROM users WHERE email = '$email' ";
        $run_get_data = DB::select($get_data);
       

        $count = count($run_get_data);
        if($count < 1)
        {
            $current_year = date('Y');
            $check = $current_year-$year;
            
            if($check >= 18){
                $insert_data = "INSERT INTO users (f_name,l_name,email,day,month,year,gender,password) VALUES ('$f_name','$l_name','$email','$day','$month','$year','$gender','$password')";
                $run_data = DB::select($insert_data);

               

                return redirect('/')->with('sign_up_success','Sign up successfully please login');

            }else{
                return redirect('/')->with('age','Sorry!! Your age is not 18 yet.');
            }
            

        }else{
            return redirect('/')->with('email','This email are already used by another user.');
        }
      



    }

    public function login(Request $request)
    {
        $email = $request->input('email');
        $password = $request->input('password');
        $get_data = "SELECT * FROM users WHERE email = '$email' AND password=$password ";
        $run_data = DB::select($get_data);
        $count = count($run_data);
        if($count==1)
        {
            $session_id = "SELECT * FROM users WHERE email='$email' ";
            $run_data = DB::select($session_id);
            $data = $run_data;
            foreach($data as $item)
            {
               
                $session_id = $item->id;
                session()->put('session_id',$session_id);

                $update_status = "UPDATE users SET status='online' WHERE id = $session_id ";
                $run_update_status = DB::select($update_status);
            }
            
            
            
            session()->put('email',$email);
            return redirect('profile');
        }else{
            return redirect('/')->with('login_err','Your email or password is wrong');
        }
        
    }

    public function logout($id)
    {
        $update_data = "UPDATE users SET status ='offline' WHERE id=$id ";
        $run_update_data = DB::select($update_data);
        Session::flush();
        return redirect('/');
    }

    public function changeProfile(Request $request)
    {
        //upload Image

        $msg = "";
        $image = $_FILES['image']['name'];
        $target = "images/".basename($image);

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
             $msg = "Image uploaded successfully";
          }else{
             $msg = "Failed to upload image";
          }

          $id = $request->input('id');
          

        $update_data = "UPDATE users SET image=('$image') WHERE id=$id ";
        $run_data = DB::select($update_data);
        return redirect('profile');
    }

    public function addInformation(Request $request)
    {
        $university = $request->input('university');
        $address = $request->input('address');
        $phone = $request->input('phone');
        $country = $request->input('country');
        $city = $request->input('city');
        $id = $request->input('id');

        $update_data = "UPDATE users SET university=('$university'),
        address=('$address'),phone=('$phone'),country=('$country'),city=('$city') WHERE id = $id";

        $run_data=DB::select($update_data);
        return redirect('profile');
    }

    public function addFriend(request $request,$id)
    {
        $session_id = session()->get('session_id');
        $target_data = "INSERT INTO friends (user_id,friend_id) VALUES ('$session_id','$id')";
        $run_data = DB::select($target_data);
        return redirect('profile');
    }

    public function blockFriend($id)
    {
        $delete_data = "DELETE FROM friends WHERE friend_id = $id";
        $run_data = DB::select($delete_data);
        return redirect('profile');
    }

    public function dataPost(Request $request)
    {
        $session_id = $request->input('session_id');
        $text = $request->input('text');

        $get_data = "SELECT * FROM users WHERE id = $session_id";
        $run_data = DB::select($get_data);

        $data = $run_data;
        foreach($data as $item)
        {
            $user_image = $item->image;
            $f_name = $item->f_name;
            $l_name = $item->l_name;
        }

             //upload Image
             $msg = "";
             $image = $_FILES['image']['name'];
             $target = "images/".basename($image);
     
             if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                  $msg = "Image uploaded successfully";
               }else{
                  $msg = "Failed to upload image";
               }
        
        $insert_post = "INSERT INTO post (user_id,text,image,user_image,f_name,l_name) VALUES ('$session_id','$text','$image','$user_image','$f_name','$l_name')";
        $run_insert_post = DB::select($insert_post);
        return redirect('/profile');

        
    }

    public function addPicture(Request $request)
    {
        $user_id = $request->input('user_id');
        $user_comment = $request->input('comment');
         //upload Image

         $msg = "";
         $image = $_FILES['image']['name'];
         $target = "images/".basename($image);
 
         if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
              $msg = "Image uploaded successfully";
           }else{
              $msg = "Failed to upload image";
           }

           $insert_data="INSERT INTO album (user_id,image,user_comment) VALUES ('$user_id','$image','$user_comment')";
           $run_data = DB::select($insert_data);
           return redirect('profile');
        
    }

    public function deletePost($id)
    {
        $delete_data = "DELETE FROM post WHERE id=$id";
        $run_data = DB::select($delete_data);
        return redirect('/profile');
    }

    public function editPost(Request $request)
    {
        $post_id = $request->post_id;
        $text = $request->text;
        $check = $request->check;
        

        

           if($check)
           {
                //upload Image

                $msg = "";
                $image = $_FILES['image']['name'];
                $target = "images/".basename($image);
 
                if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                   $msg = "Image uploaded successfully";
                }else{
                   $msg = "Failed to upload image";

                $update_data = "UPDATE post SET text='$text', image='$image' WHERE id=$post_id ";
                $run_data = DB::select($update_data);
                return redirect('/profile');
           }


            

           }else{
            $update_data = "UPDATE post SET text='$text' WHERE id=$post_id ";
            $run_data = DB::select($update_data);
            return redirect('/profile');
           }

        

    }

    public function messageOffline(Request $request)
    {
        $sender_id = $request->sender;
        $receiver_id = $request->receiver;
        $text = $request->text;
        $s_f_name = $request->f_name;
        $s_l_name = $request->l_name;

        $get_data = "SELECT * FROM users WHERE id =$sender_id";
        $run_data = DB::select($get_data);
        $data = $run_data;
        foreach($data as $item)
        {
            $sender_image = $item->image;
        }
        
        $insert_data = "INSERT INTO message (sender_id,receiver_id,text,s_f_name,s_l_name,sender_image) 
        VALUES ('$sender_id','$receiver_id','$text','$s_f_name','$s_l_name','$sender_image')";
        $run_insert_data = DB::select($insert_data);

        return redirect('/profile');
    }

    public function messageOnline(Request $request)
    {
        $sender_id = $request->sender;
        $receiver_id = $request->receiver;
        $text = $request->text;
        $s_f_name = $request->f_name;
        $s_l_name = $request->l_name;

        $get_data = "SELECT * FROM users WHERE id =$sender_id";
        $run_data = DB::select($get_data);
        $data = $run_data;
        foreach($data as $item)
        {
            $sender_image = $item->image;
        }
        
        $insert_data = "INSERT INTO message (sender_id,receiver_id,text,s_f_name,s_l_name,sender_image) 
        VALUES ('$sender_id','$receiver_id','$text','$s_f_name','$s_l_name','$sender_image')";
        $run_insert_data = DB::select($insert_data);

        return redirect('/profile');
    }

    public function deleteMessage($id)
    {
        $delete_data = "DELETE FROM message WHERE id = $id";
        $run_delete_data = DB::select($delete_data);
        return redirect('/profile'); 
    }
}
